package Main;

import java.util.Scanner;

public class Sumdigits {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // รับ Input เป็นจำนวนเต็มบวกที่ไม่น้อยกว่าสองหลัก
        System.out.print("ป้อนจำนวนเต็ม (ไม่น้อยกว่าสองหลัก): ");
        int number = scanner.nextInt();

        if (number < 10) {
            System.out.println("กรุณาป้อนจำนวนเต็มที่ไม่น้อยกว่าสองหลัก");
            return;
        }

        System.out.print("การบวกแต่ละรอบ: ");
        while (number >= 10) {
            int sum = 0;
            int[] digits = new int[10];
            int count = 0;

            while (number > 0) {
                int digit = number % 10;
                sum += digit;
                digits[count] = digit;
                count++;
                number /= 10;
            }

            for (int i = count - 1; i >= 0; i--) {
                System.out.print(digits[i]);
                if (i > 0) {
                    System.out.print(" + ");
                } else {
                    System.out.print(" = ");
                }
            }

            number = sum;
            System.out.print(number);

            if (number >= 10) {
                System.out.print(" -> ");
            }
        }

        // แสดงผลลัพธ์ที่เหลือเพียงหลักเดียว
        System.out.println("\nผลลัพธ์ที่เหลือเพียงหลักเดียว: " + number);
    }
}
